from flask import Flask, request, jsonify
from flask_cors import CORS
import paho.mqtt.client as mqtt
import psycopg2

app = Flask(__name__)
CORS(app)

# Συνάρτηση που θα καλείται όταν ο MQTT client λαμβάνει μηνύματα
def on_message(client, userdata, message):
    try:
        topic = message.topic
        payload = message.payload.decode('utf-8')  # Αποκωδικοποίηση του payload
        print(f"Λάβαμε μήνυμα: {payload} από το θέμα: {topic}")

        # Μετατροπή του payload σε αριθμητική τιμή
        try:
            payload_value = float(payload)
        except ValueError:
            print(f"Σφάλμα: το payload '{payload}' δεν είναι έγκυρη αριθμητική τιμή.")
            return  

        # Αποθήκευση της τιμής στη βάση δεδομένων
        save_status = save_data_to_database(
            userdata['user_id'],
            userdata['username'],
            topic,
            userdata['sensor_name'],
            payload_value,
            userdata['unit'],
            userdata['description'],
            userdata['hostname']
        )
        if save_status.get('status') == 'error':
            print(f"Σφάλμα στην αποθήκευση της τιμής στη βάση: {save_status['message']}")
        else:
            print(f"Η τιμή αποθηκεύτηκε επιτυχώς στη βάση: {payload_value}")

    except Exception as e:
        print(f"Σφάλμα στην επεξεργασία του μηνύματος: {e}")

# Συνάρτηση για να ξεκινήσει το subscribe στον broker με παραμέτρους από τον χρήστη
def mqtt_subscribe(hostname, port, topic, username, password, sensor_name, unit, description, user_id):
    client = mqtt.Client(userdata={
        'user_id': user_id,
        'username': username,
        'sensor_name': sensor_name,
        'unit': unit,
        'description': description,
        'hostname': hostname
    })

    if username and password:
        client.username_pw_set(username, password)

   
    client.on_message = on_message

    try:
        
        client.connect(hostname, port, 60)

        client.subscribe(topic)

        client.loop_start()

        return {'status': 'success', 'message': 'Συνδεθήκαμε και εγγραφήκαμε στο θέμα επιτυχώς.'}

    except Exception as e:
        print(f"Σφάλμα κατά τη σύνδεση στον MQTT broker: {e}")
        return {'status': 'error', 'message': str(e)}

# Διαδρομή στο Flask που θα ξεκινά το MQTT subscribe με τα στοιχεία που στέλνει ο χρήστης
@app.route('/subscribe', methods=['POST'])
def subscribe():
    data = request.get_json()

    hostname = data.get('hostname')
    port = int(data.get('port'))
    username = data.get('username')
    password = data.get('password')
    topic = data.get('topic')
    sensor_name = data.get('sensorName')
    unit = data.get('unit')
    description = data.get('description')
    user_id = data.get('user_id')  

    
    if not all([hostname, port, topic, sensor_name, description, user_id]):
        return jsonify({'status': 'error', 'message': 'Κάποια από τα απαραίτητα πεδία λείπουν.'}), 400


    subscribe_status = mqtt_subscribe(hostname, port, topic, username, password, sensor_name, unit, description, user_id)

    if subscribe_status['status'] == 'success':
        # Αν η εγγραφή στο MQTT ήταν επιτυχής, αποθηκεύουμε και τη συνδρομή στη βάση
        subscription_status = save_subscription_to_database(sensor_name, topic, hostname, port, username, password, unit, description, user_id)
        if subscription_status['status'] == 'error':
            return jsonify(subscription_status), 500

    return jsonify(subscribe_status)

# Συνάρτηση για αποθήκευση της τιμής στη βάση δεδομένων
def save_data_to_database(user_id, username, topic, sensor_name, value, unit, description, hostname):
    connection = None
    cursor = None

    try:
        connection = psycopg2.connect(
            host="localhost",
            database="AnalyticaWeb",
            user="postgres",
            password="1234"
        )
        cursor = connection.cursor()

    
        cursor.execute(""" 
            INSERT INTO mqtt_topics (user_id, username, topic, sensor_name, value, unit, description, hostname)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (user_id, username, topic, sensor_name, value, unit, description, hostname))

        connection.commit()

        return {'status': 'success'}
    
    except Exception as e:
        print("Σφάλμα αποθήκευσης στη βάση δεδομένων:", e)
        return {'status': 'error', 'message': str(e)}
    
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

# Συνάρτηση για αποθήκευση συνδρομής στον πίνακα mqtt_subscriptions
def save_subscription_to_database(sensor_name, topic, hostname, port, username, password, unit, description, user_id):
    connection = None
    cursor = None

    try:
        connection = psycopg2.connect(
            host="localhost",
            database="AnalyticaWeb",
            user="postgres",
            password="1234"
        )
        cursor = connection.cursor()

        # Εισαγωγή της συνδρομής στον πίνακα mqtt_subscriptions
        cursor.execute(""" 
            INSERT INTO mqtt_subscriptions (user_id, sensor_name, topic, hostname, port, username, password, unit, description)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (user_id, sensor_name, topic, hostname, port, username, password, unit, description))

        connection.commit()

        return {'status': 'success'}
    
    except Exception as e:
        print("Error saving subscription to database:", e)
        return {'status': 'error', 'message': str(e)}
    
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

# Συνάρτηση για επανασύνδεση σε όλους τους ενεργούς subscribers
def reconnect_subscribers():
    connection = None
    cursor = None

    try:
        connection = psycopg2.connect(
            host="localhost",
            database="AnalyticaWeb",
            user="postgres",
            password="1234"
        )
        cursor = connection.cursor()

        # Λήψη όλων των συνδρομών από τη βάση
        cursor.execute("SELECT user_id, sensor_name, topic, hostname, port, username, password, unit, description FROM mqtt_subscriptions")
        subscriptions = cursor.fetchall()

        for sub in subscriptions:
            user_id, sensor_name, topic, hostname, port, username, password, unit, description = sub
            mqtt_subscribe(hostname, port, topic, username, password, sensor_name, unit, description, user_id)

    except Exception as e:
        print("Error reconnecting subscribers:", e)

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

if __name__ == '__main__':
    # Επανασύνδεση στους subscribers κατά την εκκίνηση
    reconnect_subscribers()

    # Εκκίνηση του Flask server
    app.run(debug=True, host='0.0.0.0', port=5000)
