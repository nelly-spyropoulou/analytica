<?php
session_start();

require 'vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Csv;

if (isset($_FILES['file'])) {
    
    $arr_file_types = ['text/csv', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
  
    if (!(in_array($_FILES['file']['type'], $arr_file_types))) {
        echo "false";
        return;
    }
  
    $username = $_SESSION['username'];  // Χρήση του username από τη session
    
    if (!file_exists('uploads/' . $username)) {
        mkdir('uploads/' . $username, 0777, true);  
    }
  
    $filename = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileExt = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $fileDestination = 'uploads/' . $username . '/' . $filename;
    
    move_uploaded_file($fileTmpName, $fileDestination);  // Αποθήκευση αρχείου στον φάκελο του χρήστη

    // Μετατροπή σε CSV
    $csvFile = 'uploads/' . $username . '/' . pathinfo($filename, PATHINFO_FILENAME) . '.csv';

    if ($fileExt == 'xls' || $fileExt == 'xlsx') {
        $spreadsheet = IOFactory::load($fileDestination);
        $writer = new Csv($spreadsheet);
        $writer->save($csvFile);
    } else {
        // Το αρχείο είναι ήδη CSV
        rename($fileDestination, $csvFile);
    }

    // Διαγραφή του αρχικού αρχείου
    if (file_exists($fileDestination)) {
        unlink($fileDestination);
    }

    echo "Το αρχείο μεταφορτώθηκε και μετατράπηκε επιτυχώς σε CSV: " . $csvFile;
    die;
}
?>

