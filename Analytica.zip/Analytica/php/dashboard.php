<?php 
session_start();

if (!isset($_SESSION['user_id'])) {  // Έλεγχος αν υπάρχει το user_id στη συνεδρία
    die("User not logged in.");
}

$host = "localhost";
$port = "5432";
$user = "postgres";
$password = "1234";
$dbname = "AnalyticaWeb";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Σφάλμα σύνδεσης στη βάση δεδομένων: " . pg_last_error());
}

$selected_topics = $_SESSION['selected_topics'] ?? [];
$user_id = $_SESSION['user_id'];  // Χρήση του user_id αντί για username

$topics_data = [];

if (!empty($selected_topics)) {
    $placeholders = [];
    $params = [$user_id];  // Το πρώτο placeholder αντιστοιχεί στο user_id

    foreach ($selected_topics as $index => $topic) {
        $placeholders[] = '$' . ($index + 2);  // Αρχίζουμε από το $2 γιατί το $1 είναι το user_id
        $params[] = $topic;
    }

    $placeholders_str = implode(',', $placeholders);

    // Query για τις τελευταίες 10 τιμές
    $query = "SELECT topic, sensor_name, description, value, created_at, unit 
              FROM mqtt_topics 
              WHERE user_id = $1 AND topic IN ($placeholders_str) 
              ORDER BY created_at DESC 
              LIMIT 10";

    $result = pg_query_params($conn, $query, $params);

    if (!$result) {
        die("Σφάλμα κατά την εκτέλεση του ερωτήματος: " . pg_last_error());
    }

    while ($row = pg_fetch_assoc($result)) {
        $topics_data[$row['topic']]['sensor_name'] = $row['sensor_name'];
        $topics_data[$row['topic']]['description'] = $row['description'];
        $topics_data[$row['topic']]['unit'] = $row['unit']; 
        $topics_data[$row['topic']]['data'][] = [
            'value' => $row['value'],
            'timestamp' => $row['created_at']
        ];
    }

    // Αναστροφή των δεδομένων ώστε να είναι από τα παλιότερα στα νεότερα
    foreach ($topics_data as &$topic_data) {
        $topic_data['data'] = array_reverse($topic_data['data']);
    }
}

pg_close($conn);
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <title>Πίνακας Ελέγχου</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns@3.0.0"></script>
    <link rel="icon" href="../logo1.png" type="image/x-icon">
    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>
<div class="menu">
    <a href="../main.html"><img src="../images/logo.png" alt="Λογότυπο"></a>
    <a href="view_topics.php">Αισθητήρες</a>
    <a href="dashboard.php" class="active-link">Πίνακας Ελέγχου</a>
    <a href="list_files.php">Αρχεία χρήστη</a>
    <a href="logout.php">Αποσύνδεση</a>
</div>
<h2>Πίνακας Ελέγχου</h2>

<?php if (empty($topics_data)): ?>
    <p>Δεν υπάρχουν διαθέσιμα θέματα προς εμφάνιση.</p>
<?php else: ?>
    <?php foreach ($topics_data as $topic => $data): ?>
        <div class="chart-container">
            <div class="chart-info-container">
                <div class="chart-info">
                    <p><?php echo htmlspecialchars($data['sensor_name']); ?></p>
                    <p><?php echo htmlspecialchars($topic); ?></p>
                    <p><?php echo htmlspecialchars($data['description'] ?? 'Δεν υπάρχει περιγραφή'); ?></p>
                </div>
                <div class="chart-summary">
                    <span id="last_date_<?php echo htmlspecialchars($topic); ?>"></span>
                    <span id="last_value_<?php echo htmlspecialchars($topic); ?>"></span>
                </div>
            </div>
            <div class="chart-area">
                <canvas id="chart_<?php echo htmlspecialchars($topic); ?>"></canvas>
            </div>
            <div class="chart-buttons">
                <button type="button" onclick="exportData('<?php echo htmlspecialchars($topic); ?>', '<?php echo htmlspecialchars($data['description'] ?? ''); ?>')">Εξαγωγή Δεδομένων</button>
            </div>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Ελέγχουμε αν υπάρχουν δεδομένα
            const data = <?php echo json_encode($data['data']); ?>;
            const ctx = document.getElementById('chart_<?php echo htmlspecialchars($topic); ?>').getContext('2d');

            const labels = data.length > 0 ? data.map(entry => new Date(entry.timestamp)) : [];
            const values = data.length > 0 ? data.map(entry => entry.value) : [];

            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Τιμή (<?php echo htmlspecialchars($data['unit']); ?>)',
                        data: values,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 2,
                        fill: false
                    }]
                },
                options: {
                    scales: {
                        x: {
                            type: 'time',
                            time: {
                                unit: 'minute',
                                displayFormats: {
                                    minute: 'HH:mm',
                                },
                            },
                            title: {
                                display: false, 
                            },
                            ticks: {
                                autoSkip: true,
                                maxTicksLimit: 10,
                                font: {
                                    size: 10 
                                }
                            },
                            grid: {
                                display: false  
                            }
                        },
                        y: {
                            title: {
                                display: false, 
                            },
                            grid: {
                                display: false,  
                            },
                            ticks: {
                                display: true,
                                font: {
                                    size: 10 
                                }
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });

            function updateChartAndSummary(topic, chart) {
                fetch(`get_topic_data.php?topic=${encodeURIComponent(topic)}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            data.values.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

                            chart.data.labels = data.values.map(entry => new Date(entry.timestamp));
                            chart.data.datasets[0].data = data.values.map(entry => entry.value);
                            chart.update();

                            const lastEntry = data.values[data.values.length - 1];
                            document.getElementById('last_date_<?php echo htmlspecialchars($topic); ?>').textContent = new Date(lastEntry.timestamp).toLocaleDateString('el-GR');
                            document.getElementById('last_value_<?php echo htmlspecialchars($topic); ?>').textContent = `${lastEntry.value} <?php echo htmlspecialchars($data['unit']); ?>`;
                        } else {
                            console.error('Σφάλμα κατά την ανανέωση των δεδομένων:', data.message);
                        }
                    })
                    .catch(error => console.error('Σφάλμα:', error));
            }

            setInterval(() => {
                updateChartAndSummary('<?php echo htmlspecialchars($topic); ?>', chart);
            }, 1000); 
        });

        function exportData(topic, description) {
            window.location.href = `export_data.php?topic=${encodeURIComponent(topic)}`;
        }
        </script>

    <?php endforeach; ?>
<?php endif; ?>

<br><br>
</body>
</html>

