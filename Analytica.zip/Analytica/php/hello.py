from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import matplotlib.pyplot as plt
import pandas as pd
import os

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})  # Επέκταση CORS σε όλα τα endpoints

@app.route('/data', methods=['POST'])
def get_data():
    data = request.json
    x_column = data.get('xColumn')
    y_column = data.get('yColumn')
    chart_type = data.get('chartType')
    file_path = data.get('filePath')
    
    try:
        df = pd.read_csv(file_path)
    except Exception as e:
        return jsonify(status="error", message=str(e)), 500

    plt.figure(figsize=(8, 5))

    if (chart_type == 'line'):
        plt.plot(df[x_column], df[y_column])
    elif (chart_type == 'bar'):
        plt.bar(df[x_column], df[y_column])
    elif (chart_type == 'scatter'):
        plt.scatter(df[x_column], df[y_column])
    else:
        return jsonify(status="error", message="Invalid chart type"), 400

    plt.xlabel(x_column)
    plt.ylabel(y_column)
    plt.title(f'{chart_type.capitalize()} Chart of {x_column} vs {y_column}')
    
    image_path = 'static/chart.png'
    plt.savefig(image_path, transparent=True)
    plt.close()

    return jsonify(status="success", image_url=image_path)

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_file(os.path.join('static', filename))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
