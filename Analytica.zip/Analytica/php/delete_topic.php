<?php
session_start();

// Έλεγχος αν ο χρήστης είναι συνδεδεμένος
if (!isset($_SESSION['user_id'])) { // Χρησιμοποιούμε το user_id αντί για username
    die(json_encode(['status' => 'error', 'message' => 'Ο χρήστης δεν είναι συνδεδεμένος.']));
}

$host = "localhost";
$port = "5432";
$user = "postgres";
$password = "1234";
$dbname = "AnalyticaWeb";

// Σύνδεση με τη βάση δεδομένων
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    error_log('Σφάλμα σύνδεσης με τη βάση δεδομένων: ' . pg_last_error());
    die(json_encode(['status' => 'error', 'message' => 'Σφάλμα σύνδεσης με τη βάση δεδομένων.']));
}

// Ανάκτηση των δεδομένων από το POST
$data = json_decode(file_get_contents('php://input'), true);

if ($data === null) {
    error_log('Μη έγκυρα δεδομένα JSON: ' . json_last_error_msg());
    die(json_encode(['status' => 'error', 'message' => 'Μη έγκυρα δεδομένα JSON.']));
}

$topic = filter_var($data['topic'], FILTER_SANITIZE_STRING);
$sensorName = filter_var($data['sensor_name'], FILTER_SANITIZE_STRING);
$user_id = $_SESSION['user_id']; // Ανάκτηση του user_id από τη συνεδρία

// Εκτέλεση SQL εντολής για διαγραφή από mqtt_topics
$query_topics = "DELETE FROM mqtt_topics WHERE topic = $1 AND sensor_name = $2 AND user_id = $3"; // Χρησιμοποιούμε user_id
$result_topics = pg_query_params($conn, $query_topics, [$topic, $sensorName, $user_id]);

if ($result_topics) {
    // Εκτέλεση SQL εντολής για διαγραφή από mqtt_subscriptions
    $query_subscriptions = "DELETE FROM mqtt_subscriptions WHERE topic = $1 AND sensor_name = $2 AND user_id = $3"; // Χρησιμοποιούμε user_id
    $result_subscriptions = pg_query_params($conn, $query_subscriptions, [$topic, $sensorName, $user_id]);

    if ($result_subscriptions) {
        echo json_encode(['status' => 'success', 'message' => 'Η διαγραφή ολοκληρώθηκε με επιτυχία.']);
    } else {
        error_log('Σφάλμα κατά τη διαγραφή από mqtt_subscriptions: ' . pg_last_error($conn));
        echo json_encode(['status' => 'error', 'message' => 'Η διαγραφή από mqtt_subscriptions απέτυχε.']);
    }
} else {
    error_log('Σφάλμα κατά τη διαγραφή από mqtt_topics: ' . pg_last_error($conn));
    echo json_encode(['status' => 'error', 'message' => 'Σφάλμα κατά τη διαγραφή από mqtt_topics.']);
}

pg_close($conn);
?>
