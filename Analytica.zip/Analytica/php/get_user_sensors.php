<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['username'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit();
}

$host = "localhost";
$port = "5432";
$user = "postgres";
$password = "1234";
$dbname = "AnalyticaWeb";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection error.']);
    exit();
}

$username = $_SESSION['username'];

$query = "
    SELECT sensor_name, description, topic, hostname, unit
    FROM mqtt_topics
    WHERE username = $1
    GROUP BY sensor_name, description, topic, hostname, unit
";

$result = pg_query_params($conn, $query, [$username]);

if (!$result) {
    echo json_encode(['status' => 'error', 'message' => 'Query execution error.']);
    exit();
}

$topics = pg_fetch_all($result) ?: [];

echo json_encode(['status' => 'success', 'sensors' => $topics]);
pg_close($conn);
?>
