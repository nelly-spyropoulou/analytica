<?php

session_start(); // Ξεκινάμε τη συνεδρία

$host = "localhost";
$port = "5432";
$user = "postgres";
$password = "1234";
$dbname = "AnalyticaWeb";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die($translations["connection_error"] . ": " . pg_last_error());
}

$username = $_POST['username'];
$password = $_POST['password'];

// Ερώτημα για την ανάκτηση του χρήστη
$query = "SELECT * FROM signup WHERE username = $1";
$result = pg_query_params($conn, $query, array($username));

if (!$result) {
    die("Σφάλμα ερωτήματος: " . pg_last_error());
}

// Ανάκτηση των δεδομένων του χρήστη
$row = pg_fetch_assoc($result);
if ($row && password_verify($password, $row['password'])) {
    $_SESSION['username'] = $username;  
    $_SESSION['user_id'] = $row['user_id'];  
    header("Location: ../main.html");
} else {
    echo '<script type="text/javascript">
            alert("Λανθασμένο username ή κωδικός.");
            window.location.href = document.referrer;
          </script>';
}

pg_close($conn);
?>
