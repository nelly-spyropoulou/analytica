<?php 
session_start();
if (!isset($_SESSION['username'])) {
    die("User not logged in.");
}

// Προσθέστε τον user_id από την συνεδρία
$user_id = $_SESSION['user_id'];

$host = "localhost";
$port = "5432";
$user = "postgres";
$password = "1234";
$dbname = "AnalyticaWeb";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    error_log("Σφάλμα σύνδεσης με τη βάση δεδομένων: " . pg_last_error());
    die("Σφάλμα σύνδεσης με τη βάση δεδομένων.");
}

// Ερώτημα για να λάβουμε όλους τους αισθητήρες για τον συγκεκριμένο χρήστη με βάση το user_id
$query = "
    SELECT sensor_name, description, topic, hostname, unit
    FROM mqtt_subscriptions
    WHERE user_id = $1
";

$result = pg_query_params($conn, $query, [$user_id]);

if (!$result) {
    die("Query execution error.");
}

$topics = pg_fetch_all($result) ?: [];

pg_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Αισθητήρες</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="icon" href="../logo1.png" type="image/x-icon">
    <link rel="stylesheet" href="../css/view_topics.css">
    
    <script>
document.addEventListener('DOMContentLoaded', () => {
    const selectedTopics = JSON.parse(sessionStorage.getItem('selectedTopics')) || [];
    document.querySelectorAll('input[name="selected_topics[]"]').forEach(checkbox => {
        checkbox.checked = selectedTopics.includes(checkbox.value);
    });

    document.querySelectorAll('input[name="selected_topics[]"]').forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            const selected = Array.from(document.querySelectorAll('input[name="selected_topics[]"]:checked')).map(el => el.value);
            sessionStorage.setItem('selectedTopics', JSON.stringify(selected));
        });
    });

    document.querySelector('.save-button').addEventListener('click', (event) => {
        event.preventDefault();

        const selected = Array.from(document.querySelectorAll('input[name="selected_topics[]"]:checked')).map(el => el.value);

        fetch('save_selection.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ selected_topics: selected })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.status === 'success' ? 'Επιτυχής αποθήκευση!' : 'Error saving options: ' + data.message);
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error saving options.');
        });
    });
});

function deleteTopic(topic, sensorName) {
    if (confirm('Είστε σίγουροι ότι θέλετε να διαγράψετε αυτόν τον αισθητήρα;')) {
        fetch('delete_topic.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ topic: topic, sensor_name: sensorName })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                alert('Η διαγραφή ολοκληρώθηκε με επιτυχία.');
                location.reload();
            } else {
                alert('Σφάλμα κατά τη διαγραφή: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Σφάλμα κατά τη διαγραφή.');
        });
    }
}
</script>
</head>
<body>
    <div class="menu">
        <a href="../main.html">
            <img src="../images/logo.png" alt="Λογότυπο">
        </a>
        <a href="view_topics.php" class="active-link">Αισθητήρες</a>
        <a href="dashboard.php">Πίνακας Ελέγχου</a>
        <a href="list_files.php">Αρχεία χρήστη</a>
        <a href="logout.php">Αποσύνδεση</a>
    </div>
    <h2>Αισθητήρες χρήστη</h2>

    <form id="topicsForm" action="dashboard.php" method="POST">
    <?php if (!empty($topics)): ?>
        <div class="topics-table">
            <table>
                <thead>
                    <tr>
                        <th>Ονομασία Αισθητήρα</th>
                        <th>Περιγραφή</th>
                        <th>Θέμα</th>
                        <th>Όνομα Host</th>
                        <th>Μονάδα Μέτρησης</th>
                        <th>Απεικόνιση στον Πίνακα Ελέγχου</th>
                        <th>Διαγραφή</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($topics as $entry): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($entry['sensor_name']); ?></td>
                            <td><?php echo htmlspecialchars($entry['description']); ?></td>
                            <td><?php echo htmlspecialchars($entry['topic']); ?></td>
                            <td><?php echo htmlspecialchars($entry['hostname']); ?></td>
                            <td><?php echo htmlspecialchars($entry['unit']); ?></td>
                            <td>
                                <input type="checkbox" name="selected_topics[]" value="<?php echo htmlspecialchars($entry['topic']); ?>">
                            </td>
                            <td>
                                <button type="button" class="delete-button" onclick="deleteTopic('<?php echo htmlspecialchars($entry['topic']); ?>', '<?php echo htmlspecialchars($entry['sensor_name']); ?>')">
                                    &times;
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p>Δεν υπάρχουν διαθέσιμοι αισθητήρες για τον χρήστη.</p>
    <?php endif; ?>

    <div class="save-button-container">
        <button type="button" class="save-button">Αποθήκευση Επιλογών</button>
    </div>
    </form>
    
    <div class="add-topic">
        <a href="../select.php" class="add-button">Προσθήκη Αισθητήρα</a>
    </div> 
</body>
</html>
