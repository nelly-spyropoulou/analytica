<?php
session_start();

// Έλεγχος αν ο χρήστης είναι συνδεδεμένος
if (!isset($_SESSION['username'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit;
}

// Στοιχεία σύνδεσης στη βάση δεδομένων
$host = "localhost";
$port = "5432";
$user = "postgres";
$password = "1234";
$dbname = "AnalyticaWeb";

// Σύνδεση στη βάση δεδομένων
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    echo json_encode(['status' => 'error', 'message' => 'Σφάλμα σύνδεσης στη βάση δεδομένων: ' . pg_last_error()]);
    exit;
}

$username = $_SESSION['username'];

// Λήψη δεδομένων αισθητήρων από τη βάση για τον συγκεκριμένο χρήστη
$query = "SELECT sensor_name, topic, description, hostname, value, unit 
          FROM mqtt_topics 
          WHERE username = $1 
          ORDER BY sensor_name";
$result = pg_query_params($conn, $query, array($username));

if (!$result) {
    echo json_encode(['status' => 'error', 'message' => 'Error retrieving sensor data: ' . pg_last_error()]);
    exit;
}

$sensors = [];
while ($row = pg_fetch_assoc($result)) {
    $sensors[] = $row;
}

echo json_encode(['status' => 'success', 'sensors' => $sensors]);

pg_close($conn);
?>
