<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['username'])) {
    die(json_encode(['status' => 'error', 'message' => 'User not logged in.']));
}

$host = "localhost";
$port = "5432";
$user = "postgres";
$password = "1234";
$dbname = "AnalyticaWeb";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die(json_encode(['status' => 'error', 'message' => 'Database connection error.']));
}

$data = json_decode(file_get_contents('php://input'), true);

if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
    die(json_encode(['status' => 'error', 'message' => 'Invalid JSON data: ' . json_last_error_msg()]));
}

$username = $_SESSION['username'];
$sensorName = $data['sensor_name'];
$description = $data['description'];
$topic = $data['topic'];
$hostname = $data['hostname'];
$value = $data['value'];
$unit = $data['unit'];

if (empty($username) || empty($sensorName) || empty($topic) || empty($description) || empty($value) || empty($unit)) {
    die(json_encode(['status' => 'error', 'message' => 'Missing required data.']));
}

$check_query = "SELECT COUNT(*) FROM mqtt_subscriptions WHERE username = $1 AND topic = $2 AND sensor_name = $3";
$check_result = pg_query_params($conn, $check_query, [$username, $topic, $sensorName]);

if (!$check_result) {
    die(json_encode(['status' => 'error', 'message' => 'Error checking subscription: ' . pg_last_error()]));
}

$exists = pg_fetch_result($check_result, 0, 0);

if ($exists == 0) {
    $insert_subscription_query = "INSERT INTO mqtt_subscriptions (username, topic, sensor_name, description) VALUES ($1, $2, $3, $4)";
    $insert_subscription_result = pg_query_params($conn, $insert_subscription_query, [$username, $topic, $sensorName, $description]);

    if (!$insert_subscription_result) {
        die(json_encode(['status' => 'error', 'message' => 'Error inserting subscription data: ' . pg_last_error()]));
    }
}

$insert_value_query = "INSERT INTO mqtt_topics (username, topic, sensor_name, description, hostname, value, unit) VALUES ($1, $2, $3, $4, $5, $6, $7)";
$insert_value_result = pg_query_params($conn, $insert_value_query, [$username, $topic, $sensorName, $description, $hostname, $value, $unit]);

if (!$insert_value_result) {
    die(json_encode(['status' => 'error', 'message' => 'Error inserting value data: ' . pg_last_error()]));
}

echo json_encode(['status' => 'success']);
pg_close($conn);
?>
