<?php
session_start();

// Στοιχεία σύνδεσης στη βάση δεδομένων
$host = "localhost";
$port = "5432";
$user = "postgres";
$password = "1234";
$dbname = "AnalyticaWeb";

// Σύνδεση στη βάση δεδομένων
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    echo json_encode(['status' => 'error', 'message' => 'Σφάλμα σύνδεσης στη βάση δεδομένων: ' . pg_last_error()]);
    exit;
}

// Λήψη δεδομένων από το αίτημα
$data = json_decode(file_get_contents('php://input'), true);

if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON data: ' . json_last_error_msg()]);
    exit;
}

$username = $data['username'];
$topic = $data['topic'];
$sensorName = $data['sensorName'];
$description = $data['description'];
$hostname = $data['hostname'];
$value = $data['value'];
$unit = $data['unit'];

if (empty($username) || empty($topic) || empty($sensorName) || empty($description) || empty($value) || empty($unit)) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required data.']);
    exit;
}

// Έλεγχος αν η εγγραφή υπάρχει ήδη
$check_query = "SELECT COUNT(*) FROM mqtt_subscriptions WHERE username = $1 AND topic = $2 AND sensor_name = $3";
$check_result = pg_query_params($conn, $check_query, array($username, $topic, $sensorName));

if (!$check_result) {
    echo json_encode(['status' => 'error', 'message' => 'Error checking subscription: ' . pg_last_error()]);
    exit;
}

$exists = pg_fetch_result($check_result, 0, 0);

if ($exists == 0) {
    // Εισαγωγή στη βάση mqtt_subscriptions
    $insert_subscription_query = "INSERT INTO mqtt_subscriptions (username, topic, sensor_name, description) VALUES ($1, $2, $3, $4)";
    $insert_subscription_result = pg_query_params($conn, $insert_subscription_query, array($username, $topic, $sensorName, $description));

    if (!$insert_subscription_result) {
        echo json_encode(['status' => 'error', 'message' => 'Error inserting subscription data: ' . pg_last_error()]);
        exit;
    }
}

// Εισαγωγή στην mqtt_topics
$insert_value_query = "INSERT INTO mqtt_topics (username, topic, sensor_name, description, hostname, value, unit) VALUES ($1, $2, $3, $4, $5, $6, $7)";
$insert_value_result = pg_query_params($conn, $insert_value_query, array($username, $topic, $sensorName, $description, $hostname, $value, $unit));

if (!$insert_value_result) {
    echo json_encode(['status' => 'error', 'message' => 'Error inserting value data: ' . pg_last_error()]);
    exit;
}

echo json_encode(['status' => 'success']);
pg_close($conn);
?>
