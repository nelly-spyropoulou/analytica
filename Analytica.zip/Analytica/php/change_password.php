<?php

session_start(); // Ξεκινάμε τη συνεδρία


$dbconn = pg_connect("host=localhost dbname=AnalyticaWeb user=postgres password=1234")
    or die('Could not connect: ' . pg_last_error());

// Ελέγχουμε αν υπάρχουν τα στοιχεία από τη φόρμα
if(isset($_POST['username'], $_POST['new_password'], $_POST['confirm_password'])) {
    // Παίρνουμε τις τιμές από τη φόρμα
    $username = $_POST['username'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Ελέγχουμε αν ο νέος κωδικός ταιριάζει με την επιβεβαίωση
    if ($new_password !== $confirm_password) {
      echo '<script type="text/javascript">
            alert("Οι κωδικόι δεν ταιριάζουν.");
            window.location.href = "../log_in.html";
          </script>';
    }

    // Ερώτημα SQL για έλεγχο του χρήστη βάσει του username
    $check_query = "SELECT * FROM signup WHERE username='$username'";
    $check_result = pg_query($dbconn, $check_query) or die($translations["user_not_found"] . ': ' . pg_last_error());

    if (pg_num_rows($check_result) > 0) {
        // Ο χρήστης υπάρχει, οπότε ενημερώνουμε τον κωδικό
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Ερώτημα SQL για αλλαγή του κωδικού
        $update_query = "UPDATE signup SET password='$hashed_password', confirm_password='$hashed_password' WHERE username='$username'";
        $update_result = pg_query($dbconn, $update_query) or die($translations["password_change_failed"] . ': ' . pg_last_error());

        if ($update_result) {
            echo '<script type="text/javascript">
            alert("Ο κωδικός άλλαξε επιτυχώς.");
            window.location.href = "../log_in.html";
          </script>';
        } else {
            echo '<script type="text/javascript">
            alert("Αποτυχία αλλαγής κωδικού.");
            window.location.href = document.referrer; 
          </script>';
        }
    } else {
        // Ο χρήστης δεν υπάρχει
        echo '<script type="text/javascript">
        alert("Ο χρήστης δεν βρέθηκε.");
        window.location.href = document.referrer; 
      </script>';
    }
} else {
    echo '<script type="text/javascript">
    alert("Δεν συμπληρώσατε όλα τα πεδία.");
    window.location.href = document.referrer; 
  </script>';
}

pg_close($dbconn);
?>