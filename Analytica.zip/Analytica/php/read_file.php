<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: php/login.php");
    exit;
}

if (!isset($_GET['file'])) {
    header("Location: php/list_files.php");
    exit;
}

$filePath = urldecode($_GET['file']);
if (!file_exists($filePath)) {
    die('Το αρχείο δεν βρέθηκε.');
}

$fileExtension = pathinfo($filePath, PATHINFO_EXTENSION);

if ($fileExtension == 'csv') {
    $data = readCsvFile($filePath);
} elseif ($fileExtension == 'xls' || $fileExtension == 'xlsx') {
    $data = readExcelFile($filePath);
} else {
    die('Μη υποστηριζόμενος τύπος αρχείου.');
}

function readCsvFile($filePath) {
    $data = [];
    if (($handle = fopen($filePath, 'r')) !== false) {
        while (($row = fgetcsv($handle, 1000, ',')) !== false) {
            $data[] = $row;
        }
        fclose($handle);
    }
    return $data;
}

function readExcelFile($filePath) {
    require 'vendor/autoload.php';
    $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($filePath);
    $spreadsheet = $reader->load($filePath);
    $data = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
    return $data;
}

function stat_standard_deviation($arr) {
    $num_of_elements = count($arr);
    $variance = 0.0;
    $mean = array_sum($arr) / $num_of_elements;
    foreach($arr as $i) {
        $variance += pow($i - $mean, 2);
    }
    return (float)sqrt($variance / $num_of_elements);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Αποτελέσματα</title>
    <link rel="icon" href="../logo1.png" type="image/x-icon">
    <style>
        .container {
    display: flex;
    flex-wrap: wrap; 
    gap: 20px;
    padding: 20px;
    overflow-x: auto;
    background-color: transparent;
}

.data-table, .stats-table {
    flex: 1 1 300px; 
    min-width: 300px; 
    max-width: 100%;
    overflow-y: auto;
    border-radius: 8px; 
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); 
}

table {
    border-collapse: collapse;
    margin-top: 10px;
    width: 100%; 
}

th, td {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

th {
    background-color: #f2f2f2; 
}

.data-table {
    background-color: #f0f8ff; 
}

.stats-table {
    background-color: #f5f5dc; 
}

h2 {
    text-align: center;
    margin: 10px 0; 
}

    </style>
</head>
<body>

<div class="container">
    
    <div class="data-table">
        <h2>Δεδομένα Αρχείου</h2>
        <table>
            <?php
            foreach ($data as $row) {
                echo "<tr>";
                foreach ($row as $cell) {
                    echo "<td>" . htmlspecialchars($cell) . "</td>";
                }
                echo "</tr>";
            }
            ?>
        </table>
    </div>

    <!-- Πίνακας για την εμφάνιση των στατιστικών στοιχείων -->
    <div class="stats-table">
        <h2>Στατιστικά Στοιχεία</h2>
        <table>
            <?php
            $columnStatistics = [];
            foreach ($data[0] as $columnIndex => $columnName) {
                $is_numeric_column = true;
                $columnValues = [];

                foreach (array_slice($data, 1) as $row) {
                    if (isset($row[$columnIndex]) && is_numeric($row[$columnIndex])) {
                        $columnValues[] = (float) $row[$columnIndex];
                    } else {
                        $is_numeric_column = false;
                        break;
                    }
                }

                if ($is_numeric_column && !empty($columnValues)) {
                    $mean = round(array_sum($columnValues) / count($columnValues), 3);
                    $maxValue = max($columnValues);
                    $minValue = min($columnValues);
                    $range = $maxValue - $minValue;
                    $stdDev = round(stat_standard_deviation($columnValues), 3);

                    $columnStatistics[$columnName] = [
                        'mean' => $mean,
                        'max' => $maxValue,
                        'min' => $minValue,
                        'range' => $range,
                        'std_dev' => $stdDev
                    ];
                }
            }

            // Εμφάνιση των στατιστικών σε κατακόρυφο πίνακα
            foreach ($columnStatistics as $columnName => $statistics) {
                echo "<tr><th colspan='2'>$columnName</th></tr>";
                echo "<tr><td>Μέση τιμή</td><td>{$statistics['mean']}</td></tr>";
                echo "<tr><td>Μέγιστη τιμή</td><td>{$statistics['max']}</td></tr>";
                echo "<tr><td>Ελάχιστη τιμή</td><td>{$statistics['min']}</td></tr>";
                echo "<tr><td>Εύρος</td><td>{$statistics['range']}</td></tr>";
                echo "<tr><td>Απόκλιση</td><td>{$statistics['std_dev']}</td></tr>";
            }
            ?>
        </table>
    </div>
</div>

<br><br>
<a href="php/list_files.php">Πίσω στην Λίστα Αρχείων</a>

</body>
</html>
