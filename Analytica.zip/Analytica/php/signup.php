<?php

session_start();

$host = "localhost";
$port = "5432";
$user = "postgres";
$password = "1234";
$dbname = "AnalyticaWeb";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Σφάλμα σύνδεσης: " . pg_last_error());
}

// Αποδοχή των στοιχείων από το φόρμα
$firstname = $_POST["firstname"];
$lastname = $_POST["lastname"];
$email = $_POST["email"];
$username = $_POST["username"];
$password = $_POST["password"];
$birthdate = $_POST["birthdate"];

// Hashing the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Έλεγχος αν υπάρχει ήδη το username
$checkQuery = "SELECT username FROM signup WHERE username = $1";
$checkResult = pg_query_params($conn, $checkQuery, array($username));

if (!$checkResult) {
    die("Σφάλμα ερωτήματος: " . pg_last_error());
}

if (pg_num_rows($checkResult) > 0) {
    echo '<script type="text/javascript">
        alert("Αυτός ο χρήστης υπάρχει ήδη.");
        window.location.href = document.referrer;
        </script>';
} else {
    // Δημιουργία του φακέλου με το όνομα του χρήστη
    $uploadDir = "uploads/";
    $userDir = $uploadDir . $username;

    if (!file_exists($userDir)) {
        if (!mkdir($userDir, 0777, true)) {
            die('Αποτυχία δημιουργίας φακέλου: ' . $userDir);
        } else {
            echo "Δημιουργία φακέλου: " . $userDir . "<br>";
        }
    } else {
        echo "Ο φάκελος υπάρχει ήδη: " . $userDir . "<br>";
    }

    // Εισαγωγή των στοιχείων του χρήστη στη βάση δεδομένων
    $query = "INSERT INTO signup (firstname, lastname, email, username, password, birthdate)
              VALUES ($1, $2, $3, $4, $5, $6) RETURNING user_id";

    $result = pg_query_params($conn, $query, array($firstname, $lastname, $email, $username, $hashed_password, $birthdate));

    if (!$result) {
        die("Σφάλμα στο SQL ερώτημα: " . pg_last_error());
    } else {
        $user_id = pg_fetch_result($result, 0, 'user_id'); // Λάβετε το user_id από την επιστροφή
        $_SESSION['username'] = $username;  // Ανάθεση του username στην session
        $_SESSION['user_id'] = $user_id;  // Ανάθεση του user_id στην session
        header("Location: ../main.html");
    }
}

pg_close($conn);
?>
