<?php

header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['username'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit;
}

$host = "localhost";
$port = "5432";
$user = "postgres";
$password = "1234";
$dbname = "AnalyticaWeb";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection error.']);
    exit;
}

$topic = $_GET['topic'] ?? '';

if (empty($topic)) {
    echo json_encode(['status' => 'error', 'message' => 'Topic is required.']);
    exit;
}

$query = "SELECT value, created_at FROM mqtt_topics WHERE topic = $1 ORDER BY created_at DESC LIMIT 10";
$result = pg_query_params($conn, $query, [$topic]);

if (!$result) {
    echo json_encode(['status' => 'error', 'message' => pg_last_error()]);
    exit;
}

$data = [];
while ($row = pg_fetch_assoc($result)) {
    $data[] = [
        'value' => $row['value'],
        'timestamp' => $row['created_at']
    ];
}

pg_close($conn);

echo json_encode(['status' => 'success', 'values' => $data]);

