<?php
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

session_start();

if (!isset($_SESSION['username']) || !isset($_GET['topic'])) {
    die("Χρειάζεστε σύνδεση και επιλεγμένο θέμα.");
}

$host = "localhost";
$port = "5432";
$user = "postgres";
$password = "1234";
$dbname = "AnalyticaWeb";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Σφάλμα σύνδεσης στη βάση δεδομένων: " . pg_last_error());
}

$username = $_SESSION['username'];
$topic = pg_escape_string($_GET['topic']);

$query = "SELECT sensor_name, description FROM mqtt_topics WHERE username = $1 AND topic = $2 LIMIT 1";
$result = pg_query_params($conn, $query, [$username, $topic]);

if (!$result) {
    die("Σφάλμα κατά την εκτέλεση του ερωτήματος: " . pg_last_error());
}

$info = pg_fetch_assoc($result);
$sensor_name = $info['sensor_name'];
$description = $info['description'] ?? 'Δεν υπάρχει περιγραφή';

// Αντικατάσταση κενών με υπογραμμίσεις (_)
$filename_topic = str_replace(' ', '_', $topic);
$filename_sensor = str_replace(' ', '_', $sensor_name);

$query = "SELECT value, created_at FROM mqtt_topics WHERE username = $1 AND topic = $2 ORDER BY created_at ASC";
$result = pg_query_params($conn, $query, [$username, $topic]);

if (!$result) {
    die("Σφάλμα κατά την εκτέλεση του ερωτήματος: " . pg_last_error());
}

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Data');

$sheet->setCellValue('A1', 'Τιμή');
$sheet->setCellValue('B1', 'Ημερομηνία και Ώρα');

$row = 2;
while ($data = pg_fetch_assoc($result)) {
    $formatted_date = (new DateTime($data['created_at']))->format('Y-m-d H:i:s');
    $sheet->setCellValue('A' . $row, $data['value']);
    $sheet->setCellValue('B' . $row, $formatted_date);
    $row++;
}

pg_close($conn);

$filename = $filename_topic . '_' . $filename_sensor . '.xlsx';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
