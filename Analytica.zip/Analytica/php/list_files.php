<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: php/login.php");
    exit;
}

$username = $_SESSION['username'];
$folder_path = 'uploads/' . $username . '/';

$files = scandir($folder_path);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
    $file_to_delete = $folder_path . basename($_POST['file']);
    if (file_exists($file_to_delete)) {
        unlink($file_to_delete); 
        header("Location: list_files.php"); 
        exit;
    } else {
        echo "Το αρχείο δεν βρέθηκε!";
    }
}
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Λίστα Αρχείων</title>
    <link rel="icon" href="../logo1.png" type="image/x-icon">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            background-image: url(../images/banner-bg.png);
            background-size: cover;
            background-position: center;
        }
        .container {
            max-width: 800px;
            margin: 30px auto 0 auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333333;
            border-bottom: 2px solid #e0e0e0;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        li {
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .filename {
            flex: 1;
            color: #333;
        }
        .button {
            background-color: #92c1e7;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-align: center;
        }
        .button:hover {
            background-color: #0056b3;
        }
        .delete-button {
            background-color: #ff4d4d;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .delete-button:hover {
            background-color: #cc0000;
        }
        .menu {
            background-color: #f2f2f2;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 40px;
            flex-wrap: nowrap;
        }
        .menu img {
            width: 100px;
            margin-right: auto;
        }
        .menu a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            padding: 10px 40px;
            transition: background-color 0.3s ease;
            border-radius: 4px;
        }
        .menu a:hover {
            background-color: #ddd;
            color: #000;
        }
        .active-link {
            background-color: #c0bebe;
            border-radius: 4px;
        }

        .upload-button-container {
    text-align: center;
    margin-bottom: 20px;
}

.upload-button {
    display: inline-block;
    padding: 12px 36px;
    background-color: #92c1e7;
    color: white;
    font-size: 16px;
    font-weight: bold;
    text-align: center;
    border-radius: 30px; 
    border: none;
    cursor: pointer;
    text-decoration: none;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); 
    transition: transform 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease; 
    position: relative;
    overflow: hidden;
}

.upload-button:hover {
    background-color: #0056b3; 
    box-shadow: 0 8px 12px rgba(0, 0, 0, 0.2); 
    transform: translateY(-4px); 
}

.upload-button:active {
    transform: translateY(2px); 
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

        
        @media (max-width: 1200px) {
            .menu {
                gap: 8px;
            }
            .menu a {
                font-size: 15px;
                padding: 8px 30px;
            }
            .menu img {
                width: 90px;
            }
        }
        @media (max-width: 992px) {
            .menu {
                gap: 6px;
            }
            .menu a {
                font-size: 14px;
                padding: 8px 20px;
            }
            .menu img {
                width: 80px;
            }
        }
        @media (max-width: 768px) {
            .menu {
                gap: 4px;
            }
            .menu a {
                font-size: 13px;
                padding: 6px 15px;
            }
            .menu img {
                width: 70px;
            }
        }
        @media (max-width: 576px) {
            .menu {
                gap: 2px;
            }
            .menu a {
                font-size: 12px;
                padding: 5px 10px;
            }
            .menu img {
                width: 60px;
            }
        }
    </style>
</head>
<body>
<div class="menu">
<a href="../main.html">
            <img src="../images/logo.png" alt="Λογότυπο">
        </a>
    <a href="view_topics.php">Αισθητήρες</a>
    <a href="dashboard.php">Πίνακας ελέγχου</a>
    <a href="list_files.php" class="active-link">Αρχεία χρήστη</a>
    <a href="logout.php">Αποσύνδεση</a>
</div> <br>
<div class="upload-button-container">
        <a href="../index.html" class="upload-button">Προσθήκη Αρχείου</a>
    </div>
<div class="container">
   
    

    <h2>Λίστα Αρχείων του Χρήστη: <?php echo htmlspecialchars($username); ?></h2>

    <ul>
        <?php
        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..') {
                $filename = pathinfo($file, PATHINFO_FILENAME); 
                echo "<li>";
                echo "<span class='filename'>" . htmlspecialchars($filename) . "</span>";
                // Κουμπί Εμφάνισης Δεδομένων
                echo "<form method='GET' action='../result.html' style='display:inline; margin-left: 10px;'>
                        <input type='hidden' name='file' value='" . urlencode($folder_path . $file) . "'>
                        <button type='submit' class='button'>Εμφάνιση Δεδομένων - Διαγράμματος και βασικών στατιστικών</button>
                      </form>";
                // Κουμπί Διαγραφής
                echo "<form method='POST' style='display:inline; margin-left: 10px;'>
                        <input type='hidden' name='file' value='" . htmlspecialchars($file) . "'>
                        <button type='submit' name='delete' class='delete-button'>Διαγραφή</button>
                      </form>";
                echo "</li>";
            }
        }
        ?>
    </ul>
</div>


</body>
</html>
