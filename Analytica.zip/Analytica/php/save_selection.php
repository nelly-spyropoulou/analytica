<?php
session_start();

// Ελέγχει αν ο χρήστης είναι συνδεδεμένος
if (!isset($_SESSION['username'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit;
}

// Λήψη των επιλεγμένων θεμάτων από την αίτηση
$data = json_decode(file_get_contents('php://input'), true);
$selected_topics = isset($data['selected_topics']) ? $data['selected_topics'] : [];

// Αποθήκευση των επιλεγμένων θεμάτων στη συνεδρία
$_SESSION['selected_topics'] = $selected_topics;

echo json_encode(['status' => 'success']);
?>
