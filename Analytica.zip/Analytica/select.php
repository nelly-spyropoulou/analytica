<?php 
session_start();
if (!isset($_SESSION['username'])) {
    die("User not logged in.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Αισθητήρες</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="icon" href="logo1.png" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="css/select.css">
</head>
<body>
    <div class="menu">
        <a href="main.html">
            <img src="images/logo.png" alt="Λογότυπο">
        </a>
        <a href="php/view_topics.php">Αισθητήρες</a>
        <a href="php/dashboard.php">Πίνακας ελέγχου</a>
        <a href="php/list_files.php">Αρχεία χρήστη</a>
        <a href="php/logout.php">Αποσύνδεση</a>
    </div>
    
    <h2>Προσθήκη Στοιχείων Αισθητήρα Χρήστη</h2>

    <div class="form-container">
        <form id="mqttForm">
            <div class="form-group">
                <label for="sensorName">Ονομασία Αισθητήρα:</label>
                <input type="text" id="sensorName" placeholder="Εισαγάγετε το όνομα του αισθητήρα" required />
            </div>

            <div class="form-group">
                <label for="description">Περιγραφή:</label>
                <input type="text" id="description" placeholder="Εισαγάγετε περιγραφή" required />
            </div>

            <div class="form-group">
                <label for="hostname">Όνομα Host/Διεύθυνση IP:</label>
                <input type="text" id="hostname" placeholder="test.mosquitto.org" required />
            </div>

            <div class="form-group">
                <label for="port">Αριθμός Θύρας:</label>
                <input type="number" id="port" value="1883" required />
            </div>

            <div class="form-group">
                <label for="username">Όνομα Χρήστη:</label>
                <input type="text" id="username" placeholder="Εισαγάγετε το όνομα χρήστη" required />
            </div>

            <div class="form-group">
                <label for="password">Κωδικός Πρόσβασης:</label>
                <input type="password" id="password" placeholder="Εισαγάγετε τον κωδικό πρόσβασης" required />
            </div>

            <div class="form-group">
                <label for="topic">Θέμα:</label>
                <input type="text" id="topic" placeholder="Εισαγάγετε το θέμα" required />
            </div>

            <div class="form-group">
                <label for="unit">Μονάδα Μέτρησης:</label>
                <input type="text" id="unit" placeholder="Εισαγάγετε τη μονάδα μέτρησης" required />
            </div>

            <div class="button-group">
                <button type="button" id="sendButton">Αποστολή</button>
                <button type="reset" id="clearButton">Καθαρισμός</button>
                <button type="button" id="cancelButton">Ακύρωση</button>
            </div>
        </form>
    </div>

    <script>
    document.getElementById('sendButton').addEventListener('click', function() {
        const sensorName = document.getElementById('sensorName').value;
        const description = document.getElementById('description').value;
        const hostname = document.getElementById('hostname').value;
        const port = document.getElementById('port').value;
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const topic = document.getElementById('topic').value;
        const unit = document.getElementById('unit').value;

        // Υποθέτω ότι το user_id είναι διαθέσιμο στην πλευρά του client.
        // Για παράδειγμα, μπορεί να προέρχεται από τη συνεδρία
        const userId = <?php echo json_encode($_SESSION['user_id']); ?>; // Υποθέτοντας ότι το user_id αποθηκεύεται στη συνεδρία

        const data = {
            user_id: userId,  // Προσθήκη user_id στα δεδομένα που στέλνονται
            sensorName,
            description,
            hostname,
            port,
            username,
            password,
            topic,
            unit
        };

        // Αποστολή δεδομένων στον Python server για MQTT subscribe
        fetch('http://127.0.0.1:5000/subscribe', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        })
        .then(response => response.json())
        .then(result => {
            if (result.status === 'success') {
                alert('Συνδεθήκαμε στον MQTT broker και εγγραφήκαμε στο θέμα!');
                window.location.href = 'php/view_topics.php';
            } else {
                alert('Παρουσιάστηκε σφάλμα: ' + result.message);
            }
        })
        .catch(error => {
            console.error('Σφάλμα:', error);
            alert('Παρουσιάστηκε σφάλμα κατά την αποστολή.');
        });
    });

    document.getElementById('cancelButton').addEventListener('click', () => {
        window.location.href = 'php/view_topics.php';
    });
    </script>

</body>
</html> 
