//Επιλογή των απαραίτητων στοιχείων
const dropArea = document.querySelector(".drag-area"),
dragText = dropArea.querySelector("header"),
button = dropArea.querySelector("button"),
input = dropArea.querySelector("input");
let file; 
var fileobj;

button.onclick = ()=>{
  input.click(); 
  file_browse();
}

input.addEventListener("change", function(){
  file = this.files[0];
  dropArea.classList.add("active");
  showFile(); 
});

//Εάν ο χρήστης σύρει το αρχείο πάνω από το DropArea
dropArea.addEventListener("dragover", (event)=>{
  event.preventDefault(); 
  dropArea.classList.add("active");
  dragText.textContent = "Αποδέσμευση για μεταφόρτωση αρχείου";
});

//Εάν ο χρήστης αφήσει το αρχείο στο DropArea
dropArea.addEventListener("dragleave", ()=>{
  dropArea.classList.remove("active");
  dragText.textContent = "Σύρετε και αποθέστε για μεταφόρτωση αρχείου";
});

//Εάν ο χρήστης ρίξει το Αρχείο στο DropArea
dropArea.addEventListener("drop", (event)=>{
  event.preventDefault(); 
  file = event.dataTransfer.files[0];
  showFile(); 
});

function showFile() {
  let fileType = file.type;
  let validExtensions = ["application/vnd.ms-excel", "text/csv", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"];
  if (validExtensions.includes(fileType)) {
      let fileName = file.name; // Παίρνω το όνομα του αρχείου
      let fileInfoDiv = document.getElementById('fileInfo');
      fileInfoDiv.textContent = fileName;
      dropArea.appendChild(fileInfoDiv); 

// Προσθήκη κουμπιού στο dropArea
dropArea.appendChild(uploadButton);

  } else {
      alert("Λανθασμένος τύπος αρχείου!");
      dropArea.classList.remove("active");
  }
}

function upload_file(e) {
    e.preventDefault();
    fileobj = e.dataTransfer.files[0];
    js_file_upload(fileobj);
}

function file_browse() {
  document.getElementById('file').onchange = function() {
      fileobj = document.getElementById('file').files[0];
      js_file_upload(fileobj);
  };
}

function js_file_upload(file_obj) {
    if(file_obj != undefined) {
        var form_data = new FormData();                  
        form_data.append('file', file_obj);
        var xhttp = new XMLHttpRequest();
        xhttp.open("POST", "php/upload.php", true);
        xhttp.onload = function(event) {
           
            if (xhttp.status == 200) {
                console.log("Uploaded!");
            } else {
               alert(xhttp.status);
            }
        }
 
        xhttp.send(form_data);
    }
}



